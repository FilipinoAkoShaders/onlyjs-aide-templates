package code.aide.webview;

import android.app.*;
import android.content.*;
import android.icu.text.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.preference.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.*;
import java.util.*;
import org.json.*;

public class Interface {
    private Context context;
    private Activity activity;
    private MediaPlayer mediaPlayer;
    private Handler handler;

    public Interface(Context contex) {
        context = contex;
        activity = (Activity) contex;
        handler = new Handler();

    }

	/*@JavascriptInterface
	 public void playAudio(String fileName) {
	 if (mediaPlayer != null && mediaPlayer.isPlaying()) {
	 mediaPlayer.stop();
	 mediaPlayer.release();
	 mediaPlayer = null;
	 }
	 try {
	 File file = new File(context.getExternalFilesDir(null), fileName);
	 mediaPlayer = new MediaPlayer();
	 mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
	 mediaPlayer.setDataSource(file.getAbsolutePath());
	 mediaPlayer.prepare();
	 mediaPlayer.start();
	 } catch (IOException e) {
	 e.printStackTrace();
	 }
	 }

	 @JavascriptInterface
	 public void stopAudio() {
	 if (mediaPlayer != null && mediaPlayer.isPlaying()) {
	 mediaPlayer.stop();
	 mediaPlayer.release();
	 mediaPlayer = null;
	 }
	 }*/

	@JavascriptInterface
	public String getCurrentDateTime(String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.getDefault());
		return sdf.format(new Date());
	}

	@JavascriptInterface
	public void showToast(String message) {
		Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
	}

	@JavascriptInterface
	public void setPreference(String key, String value) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putString(key, value);
		editor.apply();
	}

	@JavascriptInterface
	public String getPreference(String key, String defaultValue) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getString(key, defaultValue);
	}

	@JavascriptInterface
	public boolean isNetworkConnected() {
		ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		return activeNetwork != null && activeNetwork.isConnected();
	}

	@JavascriptInterface
	public String getDeviceInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("Brand: ").append(Build.BRAND).append("\n");
		sb.append("Model: ").append(Build.MODEL).append("\n");
		sb.append("OS Version: ").append(Build.VERSION.RELEASE).append("\n");
		sb.append("SDK Version: ").append(Build.VERSION.SDK_INT).append("\n");
		return sb.toString();
	}

    @JavascriptInterface
    public void closeApp() {
        activity.finishAffinity();
    }

	@JavascriptInterface
    public void saveFile(String fileName, String fileContent) {
        try {
            FileOutputStream outputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            outputStream.write(fileContent.getBytes());
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public String readFile(String fileName) {
        try {
            FileInputStream inputStream = context.openFileInput(fileName);
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();
            return new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @JavascriptInterface
    public void deleteFile(String fileName) {
        context.deleteFile(fileName);
    }

	/*@JavascriptInterface
	 public void setDB(String dbName, String key, String value) {
	 JSONObject json = getJson(dbName);
	 if (json == null) {
	 json = new JSONObject();
	 }
	 try {
	 json.put(key, value);
	 saveJson(dbName, json);
	 } catch (JSONException e) {
	 e.printStackTrace();
	 }
	 }

	 @JavascriptInterface
	 public String getDB(String dbName, String key, String defaultValue) {
	 JSONObject json = getJson(dbName);
	 if (json == null) {
	 return defaultValue;
	 }
	 try {
	 if (json.has(key)) {
	 return json.getString(key);
	 } else {
	 return defaultValue;
	 }
	 } catch (JSONException e) {
	 e.printStackTrace();
	 return defaultValue;
	 }
	 }

	 @JavascriptInterface
	 public void resetDB(String dbName) {
	 saveJson(dbName, new JSONObject());
	 }

	 @JavascriptInterface
	 public Map<String, String> getAll(String dbName) {
	 Map<String, String> map = new HashMap<>();
	 JSONObject json = getJson(dbName);
	 if (json != null) {
	 Iterator<String> keys = json.keys();
	 while (keys.hasNext()) {
	 String key = keys.next();
	 try {
	 String value = json.getString(key);
	 map.put(key, value);
	 } catch (JSONException e) {
	 e.printStackTrace();
	 }
	 }
	 }
	 return map;
	 }

	 @JavascriptInterface
	 public void deleteDB(String dbName, String key) throws JSONException {
	 JSONObject json = getJson(dbName);
	 if (json == null) {
	 return;
	 }

	 if (json.has(key)) {
	 json.remove(key);
	 saveJson(dbName, json);
	 }
	 }

	 private JSONObject getJson(String dbName) {
	 String content = readFile(dbName + ".json");
	 if (content != null) {
	 try {
	 return new JSONObject(content);
	 } catch (JSONException e) {
	 e.printStackTrace();
	 }
	 }
	 return null;
	 }

	 private void saveJson(String dbName, JSONObject json) {
	 saveFile(dbName + ".json", json.toString());
	 }*/
}

