package code.aide.webview;

import java.io.*;
import javax.websocket.*;
import javax.websocket.server.*;


@ServerEndpoint("/websocket")
public class SocketRunner {

    @OnOpen
    public void onOpen(Session session) {
        System.out.println("WebSocket connection opened: " + session.getId());
		try {
			session.getBasicRemote().sendText("Hello from the server!");
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("Received message from client: " + message);
    }

    @OnClose
    public void onClose(Session session) {
        System.out.println("WebSocket connection closed: " + session.getId());
    }
}
