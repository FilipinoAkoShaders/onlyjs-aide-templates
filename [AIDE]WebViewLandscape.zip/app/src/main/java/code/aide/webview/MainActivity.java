package code.aide.webview;

import android.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private Handler handler;
    private Runnable runnableCode;
	private static final int REQUEST_CODE = 1;
    private String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
	
	@Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }
            if (allPermissionsGranted) {
                // Permissions granted
            } else {
                Toast.makeText(this, "Permissions Denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            boolean allPermissionsGranted = true;
            for (String permission : permissions) {
                if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }
            if (!allPermissionsGranted) {
                requestPermissions(permissions, REQUEST_CODE);
            }
        }
		
		Intent socketIntent = new Intent(this, SocketServer.class)
;		
		final RendererWebView web = new RendererWebView(this);
        setContentView(web);
		
		web.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				return true; // disable the context menu
			}
		});
		
		web.setWebViewClient(new WebViewClient() {
			    /*@Override
			    public void onPageFinished(WebView view, String url) {
			        super.onPageFinished(view, url);
			        String js = "var meta = document.createElement('meta');\n" +
			                    "meta.setAttribute('name', 'viewport');\n" +
			                    "meta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');\n" +
			                    "document.getElementsByTagName('head')[0].appendChild(meta);\n" +
			                    "var body = document.getElementsByTagName('body')[0];\n" +
			                    "body.style.width = window.innerWidth + 'px';\n" +
			                    "body.style.height = window.innerHeight + 'px';";
			        web.evaluateJavascript(js, null);
			    }*/
				@Override
				public void onPageFinished(WebView view, String url) {
					view.loadUrl("javascript:document.body.style.zoom = window.innerWidth / document.body.scrollWidth;");
				}
			});
        
		web.setWebChromeClient(new WebChromeClient() {
			@Override
		    public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
		        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
		        builder.setMessage(message)
		               .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
		                   public void onClick(DialogInterface dialog, int id) {
		                       result.confirm();
		                   }
		               });
		        builder.setCancelable(false);
		        builder.create().show();
		        return true;
		    }
		
		    @Override
		    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
			    final View promptView = LayoutInflater.from(view.getContext()).inflate(R.layout.prompt_dialog, null);
			
		        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
		        builder.setMessage(message)
		                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
		                    public void onClick(DialogInterface dialog, int id) {
		                        String value = ((EditText) promptView.findViewById(R.id.editText)).getText().toString();
		                        result.confirm(value);
		                    }
		                })
		                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
		                    public void onClick(DialogInterface dialog, int id) {
		                        result.cancel();
		                    }
		                });
		        builder.setCancelable(false);
		        builder.setView(R.layout.prompt_dialog);
		        builder.create().show();
		        return true;
		    }
		});
		
		web.loadUrl("file:///android_asset/render.html");
    }
    
	@Override
    protected void onDestroy() {
        super.onDestroy();
    }
	
    public boolean isNetworkAvailable(Context context) {
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
		return networkInfo != null && networkInfo.isConnected();
	}
}
