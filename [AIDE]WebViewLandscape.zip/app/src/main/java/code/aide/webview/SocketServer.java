package code.aide.webview;

import code.aide.webview.SocketRunner;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import org.glassfish.tyrus.server.Server;

public class SocketServer extends Service {
    private Server server;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        server = new Server("localhost", 8080, "/", null, SocketRunner.class);
        try {
            server.start();
            System.out.println("WebSocket server started.");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        server.stop();
        System.out.println("WebSocket server stopped.");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
